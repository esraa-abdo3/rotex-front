import Sidebar from "../componets/Dashboard/Sidebar.jsx";

export const metadata = {
  title: "Admin Dashboard",
};

export default function AdminLayout({ children }) {
  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#f5f5f3" }}>
      <Sidebar />
      <div style={{ flex: 1, padding: "32px", overflowX: "hidden", maxWidth: "100%" }}>
        {children}
      </div>
    </div>
  );
}
