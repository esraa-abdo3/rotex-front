"use client";
import { useState } from "react";

const GOVS = {
  "القاهرة": ["القاهرة","مدينة نصر","شبرا","المطرية","عين شمس","حلوان","المعادي","مصر الجديدة","الزيتون","الأميرية","بولاق","السلام","الخليفة","الدرب الأحمر","الموسكي","الساحل","شبرا الخيمة","الوايلي"],
  "الجيزة": ["الجيزة","الدقي","المهندسين","العجوزة","إمبابة","بولاق الدكرور","الهرم","فيصل","أوسيم","الواحات البحرية","كرداسة","البدرشين","العياط","أطفيح","الصف"],
  "الإسكندرية": ["الإسكندرية","المنتزه","العجمي","برج العرب","أبو قير","الرمل","المحطة","سيدي جابر","باب شرق","العامرية","ورديان"],
  "الدقهلية": ["المنصورة","طلخا","ميت غمر","أجا","المنزلة","دكرنس","بلقاس","تمي الأمديد","شربين","نبروه","السنبلاوين","الجمالية","منية النصر"],
  "الشرقية": ["الزقازيق","بلبيس","منيا القمح","أبو كبير","ههيا","الإبراهيمية","فاقوس","أبو حماد","الحسينية","كفر صقر","القنايات","العاشر من رمضان","ديرب نجم"],
  "المنوفية": ["شبين الكوم","مينوف","أشمون","الباجور","قويسنا","بركة السبع","تلا","السادات","الشهداء"],
  "البحيرة": ["دمنهور","كفر الدوار","رشيد","إدكو","أبو حمص","حوش عيسى","الدلنجات","المحمودية","إيتاي البارود","شبراخيت","وادي النطرون","النوبارية"],
  "الغربية": ["طنطا","المحلة الكبرى","كفر الزيات","زفتى","السنطة","بسيون","سمنود","قطور"],
  "كفر الشيخ": ["كفر الشيخ","دسوق","فوه","مطوبس","بلطيم","سيدي سالم","الحامول","برج البرلس","قلين"],
  "الفيوم": ["الفيوم","سنورس","إطسا","أبشواي","يوسف الصديق","طامية"],
  "بني سويف": ["بني سويف","الفشن","ببا","إهناسيا","بياض العرب","ناصر","سمسطا"],
  "المنيا": ["المنيا","ملوي","أبو قرقاص","العدوة","سمالوط","مطاي","بني مزار","دير مواس","المغاغة"],
  "أسيوط": ["أسيوط","ديروط","القوصية","منفلوط","أبو تيج","صدفا","الفتح","الغنايم","ساحل سليم","أبنوب"],
  "سوهاج": ["سوهاج","أخميم","جرجا","المراغة","دار السلام","جهينة","المنشأة","البلينا","طما","طهطا"],
  "قنا": ["قنا","نجع حمادي","دشنا","قوص","فرشوط","أبو تشت","نقادة","الوقف"],
  "الأقصر": ["الأقصر","إسنا","أرمنت","الطود","القرنة"],
  "أسوان": ["أسوان","كوم أمبو","إدفو","نصر النوبة","دراو","أبو سمبل السياحية"],
  "البحر الأحمر": ["الغردقة","سفاجا","القصير","مرسى علم","رأس غارب","الشلاتين"],
  "الوادي الجديد": ["الخارجة","الداخلة","الفرافرة","بريس"],
  "مطروح": ["مرسى مطروح","الحمام","الضبعة","سيوة","الواحات","النجيلة"],
  "شمال سيناء": ["العريش","رفح","الشيخ زويد","بئر العبد","الحسنة","نخل"],
  "جنوب سيناء": ["الطور","شرم الشيخ","دهب","نويبع","طابا","أبو رديس","رأس سدر"],
  "الإسماعيلية": ["الإسماعيلية","التل الكبير","القصاصين","فايد","أبو صوير"],
  "السويس": ["السويس","عتاقة","الجناين","فيصل"],
  "بورسعيد": ["بورسعيد","بورفؤاد","بور الصياد","بور الجميل","الزهور","المناخ","الشرق"],
  "دمياط": ["دمياط","رأس البر","الزرقا","فارسكور","كفر سعد","عزبة البرج"],
};
   const settings = {
    brand: "RooteX",
    hook: (
  <>
    كل شعرة بتقع… مش بس من شعرك.
    <br />
    <br />

    بتاخد معاها جزء من{" "}
    <span
      className="font-bold"
      style={{
        color: "gold",
      }}
    >
      ثقتك
    </span>
    …{" "}
    <span
      className="font-bold"
      style={{
        color: "gold",
      }}
    >
      أنوثتك
    </span>
    …
    <br />
    وإحساسك بنفسك.
    <br />
    وبقيتي تخافي تبصي في المراية
    <br />
    أكتر ما تبصي للناس.
  </>
   ),

  

    buttonText: "ابدئي رحلة استعادة شعرك",

    colors: {
      primaryDark: "#1a1f0e",
      secondaryDark: "#2d3518",
      primary: "#3a4520",
      gold: "#c8a93e",
      goldLight: "#d4b84a",
    },

    image: "/file0000000002cc71f49e513e397c44fcd8.png",
  };

export default function Checkout({ product }) {
  const [qty, setQty] = useState(1);
  const [payMethod, setPayMethod] = useState("cash");
  const [form, setForm] = useState({ name: "", email: "", phone: "", gov: "", city: "", address: "" });
  const [errors, setErrors] = useState({});

  const set = (k, v) => setForm(p => ({ ...p, [k]: v, ...(k === "gov" ? { city: "" } : {}) }));
  const cities = form.gov ? GOVS[form.gov] ?? [] : [];
  const total = qty * (product?.price ?? 0);

  const inputCls = (k) =>
    `border rounded-xl px-3 py-2 text-sm outline-none transition w-full
     ${errors[k] ? "border-red-400 ring-2 ring-red-100" : "border-gray-200 focus:ring-2 focus:ring-blue-100 focus:border-blue-400"}`;

  const validate = () => {
    const e = {};
    if (form.name.trim().length < 3) e.name = "من فضلك أدخل اسمك";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "إيميل غير صحيح";
    if (!/^01[0-9]{9}$/.test(form.phone)) e.phone = "رقم غير صحيح (11 رقم يبدأ بـ 01)";
    if (!form.gov) e.gov = "اختر المحافظة";
    if (!form.city) e.city = "اختر المدينة";
    if (form.address.trim().length < 5) e.address = "أدخل عنوانك بالتفاصيل";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    console.log("order:", { form, qty, payMethod, total });
  };

  return (
    <div className="w-[80%] md:w-[80%] mx-auto grid grid-cols-2 gap-5 p-6 font-sans">

     
      <div className="bg-white rounded-2xl border border-gray-200 p-5 flex flex-col gap-4">
        <p className="text-xs text-gray-400 uppercase tracking-widest border-b pb-2">المنتج</p>

        <div className="aspect-square bg-gray-50 rounded-xl border border-gray-100 overflow-hidden">
          <img src={product?.images?.[0]} alt="product" className="w-full h-full object-cover" />
        </div>

        <div>
          <p className="text-lg font-bold" style={{color:settings.colors.primary}}>{product?.name?.ar ?? product?.name?.en}</p>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm" style={{color:settings.colors.primary}}>سعر القطعة</span>
          <span className="text-xl font-bold" style={{color:settings.colors.gold}}>{product?.price} جنيه</span>
        </div>

        <div className="flex items-center justify-between">
          <p className="text-sm text-black">من فضلك اختار الكمية</p>
          <div className="flex items-center text-black gap-3 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 w-fit">
            <button
              onClick={() => setQty(q => Math.max(1, q - 1))}
              className="w-7 h-7 rounded-full border text-black border-gray-200 bg-white flex items-center justify-center text-lg leading-none hover:bg-gray-100 active:scale-95 transition"
            >−</button>
            <span className="text-base font-medium min-w-[20px] text-center" style={{color:settings.colors.gold}}>{qty}</span>
            <button
              onClick={() => setQty(q => q + 1)}
              className="w-7 h-7 rounded-full text-black border border-gray-200 bg-white flex items-center justify-center text-lg leading-none hover:bg-gray-100 active:scale-95 transition"
            >+</button>
          </div>
        </div>

        <hr className="border-gray-100" />

        <div className="flex items-center justify-between bg-gray-50 border border-gray-100 rounded-xl px-4 py-3">
          <span className="text-sm " style={{color:settings.colors.primary}}>الإجمالي</span>
          <span className="text-lg font-medium" style={{color:settings.colors.gold}}>{total.toLocaleString("ar-EG")} جنيه</span>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-200 p-5 flex flex-col gap-4">
        <p className="text-xs text-gray-400 uppercase tracking-widest border-b pb-2">بيانات الطلب</p>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1" style={{color:settings.colors.primary}}>
            <label className="text-sm font-medium" style={{color:settings.colors.primary}}>الاسم الكامل</label>
            <input className={inputCls("name")} placeholder="محمد أحمد"
                          value={form.name} onChange={e => set("name", e.target.value)}
                          style={{color:settings.colors.primary , fontSize:"16px"}}
                      />
            {errors.name && <span className="text-xs text-red-500">{errors.name}</span>}
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium" style={{color:settings.colors.primary}}>الإيميل</label>
            <input className={inputCls("email")} placeholder="example@email.com" type="email" dir="ltr"
                          value={form.email} onChange={e => set("email", e.target.value)}
                          style={{color:settings.colors.primary , fontSize:"16px"}}
                      />
            {errors.email && <span className="text-xs text-red-500">{errors.email}</span>}
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-smfont-medium"  style={{color:settings.colors.primary}}>رقم التليفون</label>
          <input className={inputCls("phone")} placeholder="01xxxxxxxxx" maxLength={11} dir="ltr"
                      value={form.phone} onChange={e => set("phone", e.target.value)}
                      style={{color:settings.colors.primary , fontSize:"16px"}}
                  />
          {errors.phone && <span className="text-xs text-red-500">{errors.phone}</span>}
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium"  style={{color:settings.colors.primary}}>المحافظة</label>
                      <select className={inputCls("gov")} value={form.gov} onChange={e => set("gov", e.target.value)}
                       style={{color:settings.colors.primary , fontSize:"16px"}}
                      >
              <option value="">اختر المحافظة</option>
              {Object.keys(GOVS).map(g => <option key={g} value={g}>{g}</option>)}
            </select>
            {errors.gov && <span className="text-xs text-red-500">{errors.gov}</span>}
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-sm font-medium" style={{color:settings.colors.primary}}>المدينة / المركز</label>
            <select className={inputCls("city")} value={form.city} disabled={!form.gov}
                          onChange={e => set("city", e.target.value)
                              
                          }
                           style={{color:settings.colors.primary , fontSize:"16px"}}
                      >
              <option value="">{form.gov ? "اختر المدينة" : "اختر المحافظة أولاً"}</option>
              {cities.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            {errors.city && <span className="text-xs text-red-500">{errors.city}</span>}
          </div>
        </div>

        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium" style={{color:settings.colors.primary}}>العنوان بالتفاصيل</label>
                  <textarea className={inputCls("address")} rows={3}
                       style={{color:settings.colors.primary , fontSize:"16px"}}
            placeholder="الشارع، رقم المبنى، الدور، الشقة..."
            value={form.address} onChange={e => set("address", e.target.value)} />
          {errors.address && <span className="text-xs text-red-500">{errors.address}</span>}
        </div>

        <hr className="border-gray-100" />

        <p className="text-m font-medium" style={{color:settings.colors.primary}}>طريقة الدفع</p>
        <div className="flex gap-3">
          {[
            { key: "cash", label: "كاش", icon: "💵" },
            { key: "visa", label: "فيزا", icon: "💳" },
          ].map(opt => (
            <button key={opt.key} onClick={() => setPayMethod(opt.key)}
              className={`flex-1 flex flex-col items-center gap-1 py-3 rounded-xl border transition
                ${payMethod === opt.key
                  ? "border-blue-500 bg-blue-50 text-blue-600 border-2"
                  : "border-gray-200 bg-white text-gray-500 hover:bg-gray-50"}`}>
              <span className="text-2xl">{opt.icon}</span>
              <span className="text-sm font-medium">{opt.label}</span>
            </button>
          ))}
        </div>

        <hr className="border-gray-100" />

        <div className="flex flex-col gap-2 text-sm">
          {[
            ["عدد القطع", `${qty} قطعة`],
            ["سعر القطعة", `${product?.price} جنيه`],
            ["المحافظة", form.gov || "—"],
            ["المدينة", form.city || "—"],
            ["الدفع", payMethod === "cash" ? "كاش" : "فيزا"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between">
              <span className="text-gray-950">{k}</span>
              <span className="font-medium" style={{color:settings.colors.primary}}>{v}</span>
            </div>
          ))}
          <div className="flex justify-between font-medium text-base mt-1">
            <span style={{color:settings.colors.primary}}>الإجمالي</span>
            <span className="font-bold"style={{color:settings.colors.gold}}>{total.toLocaleString("ar-EG")} جنيه</span>
          </div>
        </div>

        <button onClick={handleSubmit}
          className="w-full py-3 rounded-xl bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 active:scale-[0.98] transition">
          تأكيد الطلب
        </button>
      </div>
    </div>
  );
}