import Link from "next/link";

export default function Product({ settings, product }) {
  const item = product?.[0];

  if (!item) return null;

  return (
    <section
      id="product"
          dir="rtl"
      className=" w-[80%] m-auto flex flex-col md:flex-row  justify-center gap-10 px-6 py-16"
      style={{
          margin:"50px auto",
        color: "#fff",
      }}
    >
  
      <div className="flex-1 flex justify-center">
        <img
          src={item.images?.[0]}
          alt={item.name?.ar}
          className="w-[250px] md:w-[600px] rounded-2xl shadow-2xl "
        />
      </div>


      <div className="flex-1 space-y-5">


    <h2 className="text-3xl font-bold leading-tight text-black relative inline-block">
  {item.name?.ar.split("-")[0]}

  <span className=" inline-block text-black">
    {item.name?.ar.split("-")[1]}


    <span
      className="absolute left-0 -bottom-2 h-0.5 w-full"
      style={{
        background: settings.colors.gold,
      }}
    />
  </span>
</h2>

 

     
        <p className="text-sm opacity-80 whitespace-pre-line" style={{color:settings.colors.primary}}>
          {item.description?.ar}
        </p>

    


        <div className="pt-4">
          <Link href={"/checkoutpage"}>
          <button
            className="px-15 py-3 rounded-full font-bold transition-all hover:scale-105 cursor-pointer duration-300"
            style={{
              background: settings.colors.gold,
              color: "#1a1a0a",
            }}
          >
            
            اشتري الآن
            </button>
            </Link>

     
        </div>
      </div>
    </section>
  );
}