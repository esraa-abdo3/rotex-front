export default function Navbar({ settings }) {
  return (
    <nav
      className="flex items-center justify-between px-6 py-4 border-b"
      style={{borderBottom:`1px solid ${settings.colors.primary}`}}
   
    >
     
      <div
        className="text-xl font-bold tracking-wide"
        style={{
          color: settings.colors.primary,
        }}
      >
        Roote<span   style={{
          color: settings.colors.gold,
        }}>x</span>
       
      </div>

  
      <ul className="flex items-center gap-6 text-sm text-white">
        

      </ul>
    </nav>
  );
}