
import Herosection from "./componets/herosection/herosection";
import Navbar from "./componets/Navbar/Navbar";
import Product from "./componets/product/product";
import Review from "./componets/review/review";
import Result from "./componets/result/result";
import Footer from "./componets/Footer/Footer";
async function getProduct() {
  const res = await fetch("https://rootex-backend.vercel.app/api/v1/product/getallproducts", {
    cache: "no-store", 
  });

  if (!res.ok) {
    throw new Error("Failed to fetch products");
  }

  return res.json();
}
export default async function Home() {
  const product = await getProduct();
  

    const settings = {
    brand: "RooteX",
hook: (
  <>
    كل شعرة بتقع… مش بس من شعرك.
    بتاخد معاها جزء من
    <span
      className="font-bold"
      style={{
        color: "gold",
      }}
    >
      ثقتك
    </span>
    …{" "}
    <span
      className="font-bold"
      style={{
        color: "gold",
      }}
    >
      أنوثتك
    </span>
    …
    <br />
    وإحساسك بنفسك.
    <br />
    وبقيتي تخافي تبصي في المراية
    <br />
    أكتر ما تبصي للناس.
  </>
),

  

    buttonText: "ابدئي رحلة استعادة شعرك",

    colors: {
      primaryDark: "#1a1f0e",
      secondaryDark: "#2d3518",
      primary: "#3a4520",
      gold: "#c8a93e",
      goldLight: "#d4b84a",
    },

    image: "/herosection.png",
  };

  return (
    <div>
      <Navbar settings={settings}/>
      <Herosection settings={settings} />
      <Product settings={settings} product={product.data}/>
    
      <Result settings={settings} />
      <Review settings={settings} />
      <Footer settings={settings}/>
    </div>
  );
}
