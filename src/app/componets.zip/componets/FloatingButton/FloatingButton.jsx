// "use client";

// import Link from "next/link";
// import { useSettings } from "../../providers/SettingsProvider";


// export default function FloatingButton() {
//   const settings = useSettings();
//   if (!settings?.floatingButton?.visible) return null;

//   return (
//     <Link
//       href="/checkoutpage"
//       style={{
//         position: "fixed",
//         bottom: "20px",
//           left: "50%",
//          transform: "translateX(-50%)",
//         zIndex: 999,

//         background:
//           settings?.colors?.buttonbackground,

//         color:
//           settings?.colors?.buttontext,

//         border: "none",
//         padding: "14px 28px",
//         borderRadius: "999px",
//         fontWeight: "700",
//         fontSize: "20px",
//           textDecoration: "none",
//         borderRadius:"14px",

//         boxShadow:
//           "0 8px 25px rgba(0,0,0,.15)",

//           minWidth: "80%",
//         margin:"0 auto",
//         textAlign: "center",
//       }}
//     >
//       {settings?.floatingButton?.text?.ar}
//     </Link>
//   );
// }
"use client";

import { useRouter } from "next/navigation";
import { useSettings } from "../../providers/SettingsProvider";
import { useQuantity } from "../../providers/QuantityProvider";
import { useLang } from "@/app/providers/LanguageProvider";

export default function FloatingButton({product}) {
  const settings = useSettings();
  const { qty, increment, decrement } = useQuantity(); // ← shared state
  const router = useRouter();
  const { lang } = useLang();

  if (!settings?.floatingButton?.visible) return null;

   const buttonbackground = settings?.colors?.buttonbackground;
  const backgroundColor = settings?.colors?.backgroundColor;
  const textColor = settings?.colors?.textColor;
  const buttontext = settings?.colors?.buttontext;
  
  const t = {
    cta: { ar: settings?.buttonText?.ar, en: settings?.buttonText?.en },
    fans: {
      ar: settings?.fansText?.ar || "بنت حبّوا النتيجة 💛",
      en: settings?.fansText?.en || "girls loved the results 💛",
    },
    currency: { ar: "جنيه", en: "EGP" },
    insteadOf: { ar: "بدلاً من", en: "Instead of" },
  };

  return (
    <div
      style={{
        position: "fixed",
        bottom: "20px",
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 999,
        width: "90%",
        maxWidth: 480,
        display: "flex",
        flexDirection: "column",
        gap: 8,
        alignItems: "center",
     
       
      }}
    >
     
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            width: "100%",
            gap: 10,
           
            direction: lang === "ar" ? "rtl" : "ltr",
          }}
        >
          {/* Quantity Control */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 14,
            }}
          >
 
<div style={{
  display: "flex",
  alignItems: "center",
  background: "#f0ecfb",
  borderRadius: "16px",
  overflow: "hidden",
              width: "fit-content",
               height:"35px",
  
}}>
  <button
    onClick={decrement}
    style={{
      width: 44, height: 44,
      display: "flex", alignItems: "center", justifyContent: "center",
      background: `${backgroundColor}22`,
      border: "none",
 
      fontSize: 16, fontWeight: 500,
   color: textColor,
      cursor: "pointer",
    }}
  >−</button>

  <span style={{
    width: 44, textAlign: "center",
    fontSize: 16, fontWeight: 700,
color: textColor,
    background: "#f0ecfb",
  }}>
    {qty}
  </span>

  <button
    onClick={increment}
    style={{
      width: 44, height: 44,
      display: "flex", alignItems: "center", justifyContent: "center",
      background: `${backgroundColor}22`,
      border: "none",
  
      fontSize: 16, fontWeight: 500,
     color: textColor,
      cursor: "pointer",
    }}
  >+</button>
</div>
          </div>

          {/* Price */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <span style={{ fontSize: 16, fontWeight: 900, color: textColor }}>
             {product[0].price} {t.currency[lang]}
            </span>
            <span style={{ fontSize: 13, color: "black" }}>{t.insteadOf[lang]}</span>
            <span style={{ fontSize: 12, color: textColor , textDecoration: "line-through", fontWeight: 500 }}>
              2700 {t.currency[lang]}
            </span>
          </div>
        </div>

   
      <button
        onClick={() => router.push(`/checkoutpage?qty=${qty}`)}
        style={{
          width: "100%",
          background: buttonbackground,
          color: buttontext,
          border: "none",
          padding: "14px 28px",
          borderRadius: "14px",
          fontWeight: "700",
          fontSize: "20px",
          textDecoration: "none",
          boxShadow: "0 8px 25px rgba(0,0,0,.15)",
          cursor: "pointer",
          fontFamily: "inherit",
          textAlign: "center",
        }}
      >
        {settings?.floatingButton?.text?.ar}
      </button>
    </div>
  );
}
