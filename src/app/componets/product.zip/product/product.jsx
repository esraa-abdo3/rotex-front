
// "use client";
// import { useState } from "react";
// import { useRouter } from "next/navigation";
// import { useSettings } from "@/app/providers/SettingsProvider";
// import { useLang } from "@/app/providers/LanguageProvider";

// export default function Product({ product }) {
//   const settings = useSettings();
//   const { lang } = useLang();
//   const item = product?.[0];
//   const [qty, setQty] = useState(1);
//   const router = useRouter();
//     const buttonbackground = settings?.colors?.buttonbackground 
//   const backgroundColor = settings?.colors?.backgroundColor 
//   const highlightColor = settings?.colors?.highlightColor
//   const textColor = settings?.colors?.textColor ;
//   const buttontext = settings?.colors?.buttontext;
//  const shippingSignature = settings?.shippingSignature;


//   if (!item || !settings) return null;

//   const name = item.name?.[lang] || item.name?.ar;
//   const description = item.description?.[lang] || item.description?.ar;
//   const nameParts = name?.split("-");

//   const t = {
//     buy: { ar: "اشتري الآن", en: "🛒 Buy Now" },
 
//     currency: { ar: "جنيه", en: "EGP" },

//   insteadOf: {ar: "بدلاً من", en: "Instead of"},
//   };

//   return (
//     <section
//       id="product"
//       dir={lang === "ar" ? "rtl" : "ltr"}
//       style={{
//         // background: "#f5f3f0",
//         padding: "10px 20px",
//         width: "100%",
//         boxSizing: "border-box",
//       }}
//     >
//       {/* Inner wrapper: column on mobile, row on desktop */}
//       <div
//         style={{
//           maxWidth: 960,
//           margin: "0 auto",
//           display: "flex",
//           flexDirection: "column",
//           gap: 10,
//         }}
//         className="product-inner"
//       >

//         {/* Product Image */}
//         <div style={{ width: "100%", borderRadius: 24, overflow: "hidden" }}>
//           <img
//             src={item.images?.[0]}
//             alt={name}
//             style={{
//               width: "85%",
//               maxHeight: "830px",
//               objectFit: "cover",
//               borderRadius: 24,
//               display: "block",
//               margin:"0 auto"
//             }}
//           />
//         </div>

//         {/* Content */}
//         <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>

//           {/* Title */}
//           <h2
//             style={{
//               fontSize: 26,
//               fontWeight: 900,
//               color: textColor,
//               margin: 0,
//               textTransform: "uppercase",
//               letterSpacing: 0.5,
//               textAlign:"center"
//             }}
//           >
//             {nameParts?.[0]}
//             {nameParts?.[1] && (
//               <span style={{ color: textColor }}> {nameParts[1]}</span>
//             )}
//           </h2>

//           {/* Description */}
//           <p
//             style={{
//               fontSize: 16,
//               color: textColor,
//               margin: 0,
//               whiteSpace: "pre-line",
//               fontWeight: 500,
//               textAlign: "center",
//               lineHeight: 1.5
//             }}
//           >
//             {description}
//           </p>

//           {/* Divider */}
//           <div style={{ height: 1, background: "#c5bfb0", opacity: 0.5 }} />

//           {/* Price + Quantity Row */}
//           <div
//             style={{
//               display: "flex",
//               alignItems: "center",
//               justifyContent: "space-between",
//               gap: 16,
//               flexDirection: lang === "ar" ? "row" : "row-reverse",
//             }}
//           >
//             {/* Quantity Control */}
//             <div
//               style={{
//                 display: "flex",
//                 alignItems: "center",
//                 gap: 16,
//                 background: "#fff",
//                 borderRadius: 50,
//                 padding: "5px 20px",
//                 border: "1px solid #e0dbd0",
//               }}
//             >
//               <button
//                 onClick={() => setQty(q => Math.max(1, q - 1))}
//                 style={{
//                   background: "none",
//                   border: "none",
//                   fontSize: 22,
//                   fontWeight: 700,
//                   color: "#3a1f6e",
//                   cursor: "pointer",
//                   lineHeight: 1,
//                   padding: 0,
//                 }}
//               >−</button>
//               <span
//                 style={{
//                   fontSize: 20,
//                   fontWeight: 700,
//                   color: "#3a1f6e",
//                   minWidth: 24,
//                   textAlign: "center",
//                 }}
//               >
//                 {qty}
//               </span>
//               <button
//                 onClick={() => setQty(q => q + 1)}
//                 style={{
//                   background: "none",
//                   border: "none",
//                   fontSize: 22,
//                   fontWeight: 700,
//                   color: "#3a1f6e",
//                   cursor: "pointer",
//                   lineHeight: 1,
//                   padding: 0,
//                 }}
//               >+</button>
//             </div>

//             {/* Price
//             {item.price && (
//               <div>
//                 <span
//                   style={{
//                     fontSize: 22,
//                     fontWeight: 900,
//                     color: "#3a1f6e",
//                   }}
//                 >
//                   {item.price * qty} {t.currency[lang]}
//                 </span>
//               </div>
//             )} */}
//             {item.price && (
//   <div
//     style={{
//       display: "flex",
//       alignItems: "center",
//       gap: 10,
//       flexWrap: "wrap",
//     }}
//               >
//                   <span
//       style={{
//         fontSize: 14,
//         fontWeight: 900,
//         color: textColor,
//       }}
//     >
//       {item.price * qty} {t.currency[lang]}
//                 </span>


//       <span
//         style={{
//           fontSize: 11,
//           color: textColor,
//           textDecoration: "line-through",
//           fontWeight: 500,
//         }}
//       >
//                       <span style={{ color: "#888" , fontSize:"10px" }}>
//       {t.insteadOf[lang]} 
//     </span>   2700 {t.currency[lang]}
//       </span>
    


  
//   </div>
// )}
//           </div>

//           {/* Buy Button */}
//           <button
//             onClick={() => router.push(`/checkoutpage?qty=${qty}`)}
//             style={{
//               width: "100%",
//               padding: "15px 0",
//               borderRadius: 50,
//               background: buttonbackground,
//               color: buttontext,
//               fontWeight: 800,
//               fontSize: 18,
//               border: "none",
//               cursor: "pointer",
//               letterSpacing: 0.5,
//               transition: "transform 0.15s, background 0.15s",
//               fontFamily: "inherit",
//             }}
//           >
//             {t.buy[lang]}
//           </button>

         
//           <div
//             style={{
//               display: "flex",
//               alignItems: "center",
//               justifyContent: "center",
//               gap: 20,
//               fontSize: 12,
//               color: "#3a1f6e",
//               opacity: 0.7,
//               flexWrap: "wrap",
//             }}
//           >
//          <span>
//     {shippingSignature?.[lang] }
//   </span>
//           </div>
//         </div>
//       </div>

//       {/* Responsive: desktop side by side */}
//       <style>{`
//         @media (min-width: 768px) {
//           .product-inner {
//             flex-direction: ${lang === "ar" ? "row" : "row-reverse"} !important;
//             align-items: center;
//           }
//           .product-inner > div:first-child {
//             flex: 1;
//           }
//           .product-inner > div:last-child {
//             flex: 1;
//           }
//         }
//       `}</style>
//     </section>
//   );
// }
"use client";
import { useRouter } from "next/navigation";
import { useSettings } from "@/app/providers/SettingsProvider";
import { useLang } from "@/app/providers/LanguageProvider";
import { useQuantity } from "@/app/providers/QuantityProvider";

export default function Product({ product }) {
  const settings = useSettings();
  const { lang } = useLang();
  const { qty, increment, decrement } = useQuantity(); // ← shared state
  const item = product?.[0];
  const router = useRouter();

  const buttonbackground = settings?.colors?.buttonbackground;
    const backgroundColor = settings?.colors?.backgroundColor;
  const textColor = settings?.colors?.textColor;
  const buttontext = settings?.colors?.buttontext;
  const shippingSignature = settings?.shippingSignature;

  if (!item || !settings) return null;

  const name = item.name?.[lang] || item.name?.ar;
  const description = item.description?.[lang] || item.description?.ar;
  const nameParts = name?.split("-");

  const t = {
    buy: { ar: "اشتري الآن", en: "🛒 Buy Now" },
    currency: { ar: "جنيه", en: "EGP" },
    insteadOf: { ar: "بدلاً من", en: "Instead of" },
  };

  return (
    <section
      id="product"
      dir={lang === "ar" ? "rtl" : "ltr"}
      style={{ padding: "10px 20px", width: "100%", boxSizing: "border-box" }}
    >
      <div
        style={{ maxWidth: 960, margin: "0 auto", display: "flex", flexDirection: "column", gap: 10 }}
        className="product-inner"
      >
        {/* Product Image */}
        <div style={{ width: "100%", borderRadius: 24, overflow: "hidden" }}>
          <img
            src={item.images?.[0]}
            alt={name}
            style={{ width: "85%", maxHeight: "830px", objectFit: "cover", borderRadius: 24, display: "block", margin: "0 auto" }}
          />
        </div>

        {/* Content */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {/* Title */}
          <h2 style={{ fontSize: 26, fontWeight: 900, color: textColor, margin: 0, textTransform: "uppercase", letterSpacing: 0.5, textAlign: "center" }}>
            {nameParts?.[0]}
            {nameParts?.[1] && <span style={{ color: textColor }}> {nameParts[1]}</span>}
          </h2>

          {/* Description */}
          <p style={{ fontSize: 16, color: textColor, margin: 0, whiteSpace: "pre-line", fontWeight: 500, textAlign: "center", lineHeight: 1.5 }}>
            {description}
          </p>

          <div style={{ height: 1, background: "#c5bfb0", opacity: 0.5 }} />

          {/* Price + Quantity Row */}
             <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            width: "100%",
            gap: 10,
           
            direction: lang === "ar" ? "rtl" : "ltr",
          }}
        >
          {/* Quantity Control */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 14,
            }}
          >
 
<div style={{
  display: "flex",
  alignItems: "center",
  background: "#f0ecfb",
  borderRadius: "16px",
  overflow: "hidden",
              width: "fit-content",
               height:"35px",
  
}}>
  <button
    onClick={decrement}
    style={{
      width: 44, height: 44,
      display: "flex", alignItems: "center", justifyContent: "center",
      background: `${backgroundColor}22`,
      border: "none",
 
      fontSize: 16, fontWeight: 500,
   color: textColor,
      cursor: "pointer",
    }}
  >−</button>

  <span style={{
    width: 44, textAlign: "center",
    fontSize: 16, fontWeight: 700,
color: textColor,
    background: "#f0ecfb",
  }}>
    {qty}
  </span>

  <button
    onClick={increment}
    style={{
      width: 44, height: 44,
      display: "flex", alignItems: "center", justifyContent: "center",
      background: `${backgroundColor}22`,
      border: "none",
  
      fontSize: 16, fontWeight: 500,
     color: textColor,
      cursor: "pointer",
    }}
  >+</button>
</div>
          </div>

          {/* Price */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            <span style={{ fontSize: 16, fontWeight: 900, color: textColor }}>
             {product[0].price} {t.currency[lang]}
            </span>
            <span style={{ fontSize: 13, color: "black" }}>{t.insteadOf[lang]}</span>
            <span style={{ fontSize: 12, color: textColor , textDecoration: "line-through", fontWeight: 500 }}>
              2700 {t.currency[lang]}
            </span>
          </div>
        </div>

          {/* Buy Button */}
          <button
            onClick={() => router.push(`/checkoutpage?qty=${qty}`)}
            style={{ width: "100%", padding: "15px 0", borderRadius: 50, background: buttonbackground, color: buttontext, fontWeight: 800, fontSize: 18, border: "none", cursor: "pointer", letterSpacing: 0.5, transition: "transform 0.15s, background 0.15s", fontFamily: "inherit" }}
          >
            {t.buy[lang]}
          </button>

          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 20, fontSize: 12, color: "#3a1f6e", opacity: 0.7, flexWrap: "wrap" }}>
            <span>{shippingSignature?.[lang]}</span>
          </div>
        </div>
      </div>

      <style>{`
        @media (min-width: 768px) {
          .product-inner { flex-direction: ${lang === "ar" ? "row" : "row-reverse"} !important; align-items: center; }
          .product-inner > div:first-child { flex: 1; }
          .product-inner > div:last-child { flex: 1; }
        }
      `}</style>
    </section>
  );
}

