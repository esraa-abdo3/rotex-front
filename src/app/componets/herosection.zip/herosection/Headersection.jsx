"use client";
import "./hersection.css";
import { useSettings } from "@/app/providers/SettingsProvider";
import { useLang } from "@/app/providers/LanguageProvider";

export default function Headersection() {
  const settings = useSettings();
  
  const { lang } = useLang();

  if (!settings) return null;

  const hook = settings.hook;
  const hookJSX = (
    <>
      {hook?.text1?.[lang]}
     

    </>
  );
    return (

<div className="hero-content">
 
      <p className="hero-hook" style={{color : settings.colors.textColor}} >
      {hookJSX}
     </p>
</div>
    )
}