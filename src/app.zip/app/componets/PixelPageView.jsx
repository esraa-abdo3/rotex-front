"use client";

import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";

export default function PixelPageView() {
  const pathname = usePathname();
  const fired = useRef(new Set());

  useEffect(() => {
    if (pathname !== "/") return;

    // منع التكرار حتى مع re-render
    if (fired.current.has(pathname)) return;
    fired.current.add(pathname);

    if (window.fbq) {
      window.fbq("track", "PageView");
      console.log("PAGE VIEW FIRED:", pathname);
    }
  }, [pathname]);

  return null;
}